//
//  BCOVSource.h
//  ios-videocloud
//
//  Created by Erik Price on 2013 07 25.
//  Copyright (c) 2013 Brightcove. All rights reserved.
//

#import <Foundation/Foundation.h>


extern NSString * const kBCOVSourceDeliveryHLS;
extern NSString * const kBCOVSourceDeliveryMP4;


@protocol BCOVMutableSource;


@protocol BCOVSource <NSObject>

@property (nonatomic, readonly, copy) NSURL *url;
@property (nonatomic, readonly, copy) NSString *deliveryMethod;
@property (nonatomic, readonly, copy) NSDictionary *properties;

- (instancetype)update:(void (^)(id<BCOVMutableSource> mutableSource))updateBlock;

@end


@protocol BCOVMutableSource <BCOVSource>

@property (nonatomic, readwrite, copy) NSURL *url;
@property (nonatomic, readwrite, copy) NSString *deliveryMethod;
@property (nonatomic, readwrite, copy) NSDictionary *properties;

@end


@interface BCOVSource : NSObject <BCOVSource, NSCopying>

- (id)initWithURL:(NSURL *)url;
- (id)initWithURL:(NSURL *)url deliveryMethod:(NSString *)deliveryMethod properties:(NSDictionary *)properties;

- (BOOL)isEqualToSource:(BCOVSource *)source;

@end