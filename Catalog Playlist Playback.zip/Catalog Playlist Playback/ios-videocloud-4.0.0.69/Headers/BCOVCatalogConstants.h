//
//  BCOVCatalogConstants.h
//  ios-catalog
//
//  Created by Mike Moscardini on 7/23/13.
//  Copyright (c) 2013 Brightcove. All rights reserved.
//

#import <Foundation/Foundation.h>


extern NSString * const kBCOVCatalogJSONDeserializationErrorRawDataKey;
extern NSString * const kBCOVCatalogJSONKeyAccountId;
extern NSString * const kBCOVCatalogJSONKeyCuePoints;
extern NSString * const kBCOVCatalogJSONKeyCustomFields;
extern NSString * const kBCOVCatalogJSONKeyDuration;
extern NSString * const kBCOVCatalogJSONKeyFLVFullLength;
extern NSString * const kBCOVCatalogJSONKeyFLVUrl;
extern NSString * const kBCOVCatalogJSONKeyHLSUrl;
extern NSString * const kBCOVCatalogJSONKeyId;
extern NSString * const kBCOVCatalogJSONKeyMetaData;
extern NSString * const kBCOVCatalogJSONKeyName;
extern NSString * const kBCOVCatalogJSONKeyPlaylistThumbnailURL;
extern NSString * const kBCOVCatalogJSONKeyReferenceId;
extern NSString * const kBCOVCatalogJSONKeyRenditions;
extern NSString * const kBCOVCatalogJSONKeyRenditionContainer;
extern NSString * const kBCOVCatalogJSONKeyRenditionURL;
extern NSString * const kBCOVCatalogJSONKeyShortDescription;
extern NSString * const kBCOVCatalogJSONKeyTime;
extern NSString * const kBCOVCatalogJSONKeyTypeEnum;
extern NSString * const kBCOVCatalogJSONKeyVideoDuration;
extern NSString * const kBCOVCatalogJSONKeyVideoStillUrl;
extern NSString * const kBCOVCatalogJSONKeyVideos;
extern NSString * const kBCOVCatalogURLParameterCommandKey;
extern NSString * const kBCOVCatalogURLParameterCommandValueFindPlaylistById;
extern NSString * const kBCOVCatalogURLParameterCommandValueFindPlaylistByReference;
extern NSString * const kBCOVCatalogURLParameterCommandValueFindVideoById;
extern NSString * const kBCOVCatalogURLParameterCommandValueFindVideoByReference;
extern NSString * const kBCOVCatalogURLParameterMediaDeliveryKey;
extern NSString * const kBCOVCatalogURLParameterMediaDeliveryValueHTTP;
extern NSString * const kBCOVCatalogURLParameterMediaDeliveryValueHTTPIOS;
extern NSString * const kBCOVCatalogURLParameterPlaylistIdKey;
extern NSString * const kBCOVCatalogURLParameterReferenceIdKey;
extern NSString * const kBCOVCatalogURLParameterTokenKey;
extern NSString * const kBCOVCatalogURLParameterVideoFieldsKey;
extern NSString * const kBCOVCatalogURLParameterVideoIdKey;
