//
//  BCOVPlaybackFacade.h
//  ios-videocloud
//
//  Created by Erik Price on 2013 09 26.
//  Copyright (c) 2013 Brightcove. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

#import "BCOVCatalogService.h"
#import "BCOVPlaybackSession.h"


@protocol BCOVPlaybackController;
@protocol BCOVPlaybackFacadeDelegate;
@protocol BCOVPlaybackQueue;


/**
 * A high-level facade which provides a configured playback queue, playback
 * controller, and any other objects needed for basic video playback use cases.
 * A playback facade should be obtained from the shared Video Cloud manager
 * object. It is safe to create multiple instances of BCOVPlaybackFacade.
 * Each facade will be responsible for loading its own enqueued videos and
 * exposing playback functionality via its own playback controller.
 */
@protocol BCOVPlaybackFacade <NSObject>

@property (nonatomic, assign) id<BCOVPlaybackFacadeDelegate> delegate;

/**
 * Specifies whether the built-in video controls are enabled.
 *
 * @return Whether the built-in video controls are enabled.
 */
@property (nonatomic, assign, getter = isControlsEnabled) BOOL controlsEnabled;

/**
 * Returns a UIView to present video playback in a view hierarchy.
 *
 * @return A UIView to present video playback in a view hierarchy.
 */
@property (nonatomic, readonly, strong) UIView *view;

/**
 * Instructs this instance to advance the queue, dequeueing a new playback
 * session. The session will be delivered via the `playbackSessions` signal.
 * This may occur asynchronously, so you must use the signal in order to take
 * action once the session is dequeued.
 */
- (void)advanceToNext;

/**
 * Instructs this instance to advance the queue, and then play the dequeued
 * session. The session will be delivered via the `playbackSessions` signal.
 * This may occur asynchronously, so this method waits for the session to
 * dequeue before playing it.
 */
- (void)advanceToNextAndPlay;

/**
 * Instructs this instance to play the currently-playing video. If no video is
 * currently playing, dequeues the first video in the queue and instructs this
 * instance to begin playing it.
 */
- (void)play;

/**
 * Instructs this instance to pause the currently-playing video. If the
 * currently-playing video is paused, or if no video is currently playing,
 * this method has no effect.
 */
- (void)pause;

/**
 * Specifies the source from which this instance will draw its upcoming videos
 * for playback. Note that setting a new source will not automatically send
 * a new playback session on `playbackSessions`; use `-advanceToNext` to send
 * a playback session for the first video in the source.
 *
 * The source is enumerated immediately upon being set and each video element
 * is defensively copied into this queue.
 *
 * @param videos The source of BCOVVideo objects from which this instance
 * should construct a queue for playback. This value is enumerated immediately
 * and its elements are copied.
 */
- (void)setVideos:(id<NSFastEnumeration>)videos;

@property (nonatomic, readonly, strong) id<BCOVPlaybackController> controller;
@property (nonatomic, readonly, strong) id<BCOVPlaybackQueue> queue;

@end


@protocol BCOVPlaybackFacadeDelegate <NSObject>

@optional

/**
 * Called when the facade's playback queue dequeues a new playback session.
 * When a delegate is set on a playback facade, this method is called with
 * the most recently dequeued playback session (if one has been dequeued).
 *
 * @param facade The playback facade whose queue dequeued the session.
 * @param session The playback session that was most recently dequeued.
 */
- (void)playbackFacade:(id<BCOVPlaybackFacade>)facade didDequeuePlaybackSession:(id<BCOVPlaybackSession>)session;

/**
 * Called when a playback session's duration is updated. When a delegate is set
 * on a playback facade, this method is called with the most recently updated
 * duration for the session. A session duration can change as the media playback
 * continues to load, as it is refined with more precise information.
 *
 * @param facade The playback facade to which this instance serves as delegate.
 * @param session The playback session that was most recently dequeued.
 * @param duration The most recently updated session duration.
 */
- (void)playbackFacade:(id<BCOVPlaybackFacade>)facade playbackSession:(id<BCOVPlaybackSession>)session didChangeDuration:(NSTimeInterval)duration;

/**
 * Called when a playback session's external playback active status is updated.
 * When a delegate is set on a playback facade, this method is called with the
 * current external playback active status for the session.
 *
 * @param facade The playback facade to which this instance serves as delegate.
 * @param session The playback session that was most recently dequeued.
 * @param externalPlaybackActive Whether external playback is active.
 */
- (void)playbackFacade:(id<BCOVPlaybackFacade>)facade playbackSession:(id<BCOVPlaybackSession>)session didChangeExternalPlaybackActive:(BOOL)externalPlaybackActive;

/**
 * Called when a session's playhead passes cue points registered with its video.
 * This will occur regardless of whether the playhead passes the cue point time
 * for standard progress (playback), or seeking (forward or backward) through
 * the media. When a delegate is set on a playback facade, this method will only
 * be called for future cue point events (any events that have already occurred
 * will not be reported).
 *
 * The cuePointInfo dictionary will contain the following keys and values for
 * each cue point event:
 *
 *   kBCOVPlaybackSessionEventKeyPreviousTime: the progress interval immediately
 *     preceding the cue points for which this event was received.
 *   kBCOVPlaybackSessionEventKeyCurrentTime: the progress interval on or
 *     immediately after the cue points for which this event was received.
 *   kBCOVPlaybackSessionEventKeyCuePoints: the BCOVCuePointCollection of cue
 *     points for which this event was received.
 *
 * If multiple cue points are registered to a time or times that fall between
 * the "previous time" and "current time" for a cue point event, all cue points
 * after the "previous time" and before or on "current time" will be included
 * in the cue point collection. Put differently, multiple cue points at the
 * same time are aggregated into a single cue point event whose collection will
 * contain all of those cue points.
 *
 * @param facade The playback facade to which this instance serves as delegate.
 * @param session The playback session that was most recently dequeued.
 * @param cuePointInfo A dictionary of information about the cue point event.
 */
- (void)playbackFacade:(id<BCOVPlaybackFacade>)facade playbackSession:(id<BCOVPlaybackSession>)session didPassCuePoints:(NSDictionary *)cuePointInfo;

/**
 * Called with the playback session's playback progress. As the session's
 * media plays, this method is called periodically with the latest progress
 * interval. When a delegate is set on a playback facade, this method will only
 * be called with progress information that has not yet occurred.
 *
 * @param facade The playback facade to which this instance serves as delegate.
 * @param session The playback session that was most recently dequeued.
 * @param progress The time interval of the session's current playback progress.
 */
- (void)playbackFacade:(id<BCOVPlaybackFacade>)facade playbackSession:(id<BCOVPlaybackSession>)session didProgressTo:(NSTimeInterval)progress;

/**
 * Called when a playback session receives a lifecycle event. When a delegate
 * is set on a playback facade, this method is called with the entire history
 * of lifecycle events that have transpired since the beginning of the session.
 * (This means that if the delegate is added mid-way through an active playback
 * session, it may be called multiple times, once for each lifecycle event that
 * has been received.)
 *
 * @param facade The playback facade to which this instance serves as delegate.
 * @param session The playback session that was most recently dequeued.
 * @param lifecycleEvent The lifecycle event received by the session.
 */
- (void)playbackFacade:(id<BCOVPlaybackFacade>)facade playbackSession:(id<BCOVPlaybackSession>)session didReceiveLifecycleEvent:(kBCOVPlaybackSessionLifecycleEvent)lifecycleEvent;

@end


@interface BCOVCatalogService (BCOVImperativeCallbacks)

/**
 * Retrieves a BCOVPlaylist from the Media API service by its playlist ID.
 *
 * @param playlistID string containing the ID of the playlist to find.
 * @param parameters Additional NSString query parameters to add to the Media API
 * requests. These values will override the default values if they conflict.
 * @param completionHandler block which will be invoked when the request finishes.  The error
 * will be populated either due to a HTTP error or a JSON parsing error.  In the case of
 * a parse error, the raw NSData response will be included in the error.userInfo, keyed by
 * kBCOVCatalogJSONDeserializationErrorRawDataKey. Execution of the completionHandler
 * will occur on the main thread.
 */
- (void)findPlaylistWithPlaylistID:(NSString *)playlistID parameters:(NSDictionary *)parameters completion:(void (^)(BCOVPlaylist *playlist, NSDictionary *jsonResponse, NSError *error))completionHandler;

/**
 * Retrieves a BCOVPlaylist from the Media API service by its reference ID.
 *
 * @param referenceID string containing the reference ID of the playlist to find.
 * @param parameters Additional NSString query parameters to add to the Media API
 * requests. These values will override the default values if they conflict.
 * @param completionHandler block which will be invoked when the request finishes.  The error
 * will be populated either due to a HTTP error or a JSON parsing error.  In the case of
 * a parse error, the raw NSData response will be included in the error.userInfo, keyed by
 * kBCOVCatalogJSONDeserializationErrorRawDataKey. Execution of the completionHandler
 * will occur on the main thread.
 */
- (void)findPlaylistWithReferenceID:(NSString *)referenceID parameters:(NSDictionary *)parameters completion:(void (^)(BCOVPlaylist *playlist, NSDictionary *jsonResponse, NSError *error))completionHandler;

/**
 * Retrieves a BCOVVideo from the Media API service by its video ID.
 *
 * @param videoID string containing the ID of the video to find.
 * @param parameters Additional NSString query parameters to add to the Media API
 * requests. These values will override the default values if they conflict.
 * @param completionHandler block which will be invoked when the request finishes.  The error
 * will be populated either due to a HTTP error or a JSON parsing error.  In the case of
 * a parse error, the raw NSData response will be included in the error.userInfo, keyed by
 * kBCOVCatalogJSONDeserializationErrorRawDataKey. Execution of the completionHandler
 * will occur on the main thread.
 */
- (void)findVideoWithVideoID:(NSString *)videoID parameters:(NSDictionary *)parameters completion:(void (^)(BCOVVideo *video, NSDictionary *jsonResponse, NSError *error))completionHandler;

/**
 * Retrieves a BCOVVideo from the Media API service by its reference ID.
 *
 * @param referenceID string containing the reference ID of the video to find.
 * @param parameters Additional NSString query parameters to add to the Media API
 * requests. These values will override the default values if they conflict.
 * @param completionHandler block which will be invoked when the request finishes.  The error
 * will be populated either due to a HTTP error or a JSON parsing error.  In the case of
 * a parse error, the raw NSData response will be included in the error.userInfo, keyed by
 * kBCOVCatalogJSONDeserializationErrorRawDataKey. Execution of the completionHandler
 * will occur on the main thread.
 */
- (void)findVideoWithReferenceID:(NSString *)referenceID parameters:(NSDictionary *)parameters completion:(void (^)(BCOVVideo *video, NSDictionary *jsonResponse, NSError *error))completionHandler;

@end
