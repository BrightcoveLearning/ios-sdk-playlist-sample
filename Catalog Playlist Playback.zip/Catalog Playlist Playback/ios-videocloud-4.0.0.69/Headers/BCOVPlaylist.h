//
//  BCOVPlaylist.h
//  ios-videocloud
//
//  Created by Erik Price on 2013 07 25.
//  Copyright (c) 2013 Brightcove. All rights reserved.
//

#import <Foundation/Foundation.h>

@class BCOVVideo;

@protocol BCOVMutablePlaylist;

@protocol BCOVPlaylist <NSObject, NSFastEnumeration>

@property (nonatomic, readonly, copy) NSArray *videos;
@property (nonatomic, readonly, copy) NSDictionary *properties;

- (instancetype)update:(void (^)(id<BCOVMutablePlaylist> mutablePlaylist))updateBlock;

@end

@protocol BCOVMutablePlaylist <BCOVPlaylist>

@property (nonatomic, readwrite, copy) NSArray *videos;
@property (nonatomic, readwrite, copy) NSDictionary *properties;

@end

@interface BCOVPlaylist : NSObject <BCOVPlaylist, NSCopying>

- (id)initWithVideos:(NSArray *)videos properties:(NSDictionary *)properties;
- (id)initWithVideos:(NSArray *)videos;

- (id)initWithVideo:(BCOVVideo *)video properties:(NSDictionary *)properties;
- (id)initWithVideo:(BCOVVideo *)video;

/**
 * Returns the video at the specified index, or nil if the specified index
 * is greater than the highest index into the playlist.
 *
 * @param index The index into this collection of the desired video.
 * @return The video at the specified index, or nil if this playlist
 * does not have a video at that index.
 */
- (BCOVVideo *)objectAtIndexedSubscript:(NSUInteger)index;

- (BOOL)isEqualToPlaylist:(BCOVPlaylist *)playlist;
- (int)count;

@end