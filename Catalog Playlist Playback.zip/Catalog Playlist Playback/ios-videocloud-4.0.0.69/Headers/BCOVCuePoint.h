//
//  BCOVCuePoint.h
//  ios-videocloud
//
//  Created by Erik Price on 2013 07 25.
//  Copyright (c) 2013 Brightcove. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>


#define kBCOVCuePointPositionTypeAfter kCMTimePositiveInfinity
#define kBCOVCuePointPositionTypeBefore kCMTimeZero


@protocol BCOVMutableCuePoint;


@protocol BCOVCuePoint <NSObject>

@property (nonatomic, readonly, assign) CMTime position;
@property (nonatomic, readonly, copy) NSString *type;
@property (nonatomic, readonly, copy) NSDictionary *properties;

- (instancetype)update:(void (^)(id<BCOVMutableCuePoint> mutableCuePoint))updateBlock;

@end


@protocol BCOVMutableCuePoint <BCOVCuePoint>

@property (nonatomic, readwrite, assign) CMTime position;
@property (nonatomic, readwrite, copy) NSString *type;
@property (nonatomic, readwrite, copy) NSDictionary *properties;

@end


@interface BCOVCuePoint : NSObject <BCOVCuePoint, NSCopying>

- (id)initWithType:(NSString *)type position:(CMTime)position;
- (id)initWithType:(NSString *)type position:(CMTime)position properties:(NSDictionary *)properties;

- (NSComparisonResult)compare:(BCOVCuePoint *)cuePoint;
- (BOOL)hasPosition:(CMTime)position;
- (BOOL)isEqualToCuePoint:(BCOVCuePoint *)cuePoint;

+ (BCOVCuePoint *)afterCuePointOfType:(NSString *)type properties:(NSDictionary *)properties;
+ (BCOVCuePoint *)beforeCuePointOfType:(NSString *)type properties:(NSDictionary *)properties;
+ (BCOVCuePoint *)cuePointWithType:(NSString *)type positionInSeconds:(NSTimeInterval)positionInSeconds properties:(NSDictionary *)properties;

@end