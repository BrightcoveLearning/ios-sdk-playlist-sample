//
//  BCOVVideo.h
//  ios-videocloud
//
//  Created by Erik Price on 2013 07 25.
//  Copyright (c) 2013 Brightcove. All rights reserved.
//

#import <Foundation/Foundation.h>


@class BCOVCuePointCollection;
@class BCOVSource;

@protocol BCOVMutableVideo;


@protocol BCOVVideo <NSObject>

@property (nonatomic, readonly, copy) BCOVCuePointCollection *cuePoints;
@property (nonatomic, readonly, copy) NSDictionary *properties;
@property (nonatomic, readonly, copy) NSArray *sources;

- (instancetype)update:(void (^)(id<BCOVMutableVideo> mutableVideo))updateBlock;

@end


@protocol BCOVMutableVideo <BCOVVideo>

@property (nonatomic, readwrite, copy) BCOVCuePointCollection *cuePoints;
@property (nonatomic, readwrite, copy) NSDictionary *properties;
@property (nonatomic, readwrite, copy) NSArray *sources;

@end


@interface BCOVVideo : NSObject <BCOVVideo, NSCopying>

- (id)initWithSources:(NSArray *)sources cuePoints:(BCOVCuePointCollection *)cuePoints properties:(NSDictionary *)properties;
- (id)initWithSource:(BCOVSource *)source cuePoints:(BCOVCuePointCollection *)cuePoints properties:(NSDictionary *)properties;

- (BOOL)isEqualToVideo:(BCOVVideo *)video;

+ (BCOVVideo *)videoWithURL:(NSURL *)url;

@end
