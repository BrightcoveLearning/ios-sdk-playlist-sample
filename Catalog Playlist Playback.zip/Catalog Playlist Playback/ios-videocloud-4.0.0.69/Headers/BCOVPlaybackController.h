//
//  BCOVPlaybackController.h
//  ios-videocloud
//
//  Created by Erik Price on 2013 08 20.
//  Copyright (c) 2013 Brightcove. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <CoreMedia/CoreMedia.h>
#import <ReactiveCocoa/ReactiveCocoa.h>


@class BCOVPlaylist;
@class BCOVSource;
@class BCOVVideo;


/**
 * Protocol adopted by objects that provide playback functionality.
 *
 * Implementations of this formal protocol must support its standard playback
 * operations, but may extend the API to perform additional functions specific
 * to their feature set.
 */
@protocol BCOVPlaybackController <NSObject>

/**
 * Whether to begin playing a new playback session as soon as it is received.
 *
 * Defaults to NO.
 *
 * @return Whether to begin playback as soon as a new session is received.
 */
@property (nonatomic, assign, getter = isAutoPlay) BOOL autoPlay;

/**
 * Returns a UIView to present playback in a view hierarchy.
 *
 * @return A UIView to present playback in a view hierarchy.
 */
@property (nonatomic, readonly, strong) UIView *view;

/**
 * Specifies that the current player, as well as any subsequent players (until
 * this property is set to a different value), should have external playback
 * enabled.
 *
 * @param allowsExternalPlayback Whether players should have external playback
 * enabled.
 */
- (void)setAllowsExternalPlayback:(BOOL)allowsExternalPlayback;

/**
 * Instructs this instance to play the currently-playing video. If no video is
 * currently playing, dequeues the first video in the queue and instructs this
 * instance to begin playing it.
 */
- (void)play;

/**
 * Instructs this instance to pause the currently-playing video. If the
 * currently-playing video is paused, or if no video is currently playing,
 * this method has no effect.
 */
- (void)pause;

/**
 * Seeks to the specified time in the currently-playing video, and returns a
 * signal that sends an error if the seek terminates prematurely due to being
 * interrupted by another seek, or sends complete if the seek finishes normally.
 *
 * @param time The destination time of the seek operation.
 * @return A signal that sends an error if the seek terminates prematurely due
 * to being interrupted by another seek, or sends complete if the seek finishes
 * normally.
 */
- (RACSignal *)seekToTime:(CMTime)time;

@end