//
//  CPPAppDelegate.h
//  Catalog Playlist Playback
//
//  Created by Robert Crooks on 10/2/13.
//  Copyright (c) 2013 Brightcove. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CPPAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
