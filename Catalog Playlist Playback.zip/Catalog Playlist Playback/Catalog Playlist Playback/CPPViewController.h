//
//  CPPViewController.h
//  Catalog Playlist Playback
//
//  Created by Robert Crooks on 10/2/13.
//  Copyright (c) 2013 Brightcove. All rights reserved.
//

#import <UIKit/UIKit.h>
// import the SDK Playback facade header
#import "BCOVPlaybackFacade.h"


@interface CPPViewController : UIViewController
// set up the player view, catalog service, and the facade
@property (strong, nonatomic) IBOutlet UIView *view;
@property (strong, nonatomic) BCOVCatalogService *catalog;
@property (strong, nonatomic) id<BCOVPlaybackFacade> facade;

@end
