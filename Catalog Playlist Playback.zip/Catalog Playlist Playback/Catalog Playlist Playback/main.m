//
//  main.m
//  Catalog Playlist Playback
//
//  Created by Robert Crooks on 10/2/13.
//  Copyright (c) 2013 Brightcove. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CPPAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([CPPAppDelegate class]));
    }
}
